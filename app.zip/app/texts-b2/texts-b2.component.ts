import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { IUnknownWord } from '../iunknownWord'
import { UnknownWordsService } from '../unknown-words.service'
import { TextIdService } from '../text-id.service'

import text1 from '../learnertexts_B2/text1.json';
import text2 from '../learnertexts_B2/text2.json';
import text3 from '../learnertexts_B2/text3.json';
import text4 from '../learnertexts_B2/text4.json';
import text5 from '../learnertexts_B2/text5.json';
import text6 from '../learnertexts_B2/text6.json';
import text7 from '../learnertexts_B2/text7.json';
import text8 from '../learnertexts_B2/text8.json';
import text9 from '../learnertexts_B2/text9.json';
import text10 from '../learnertexts_B2/text10.json';
import text11 from '../learnertexts_B2/text11.json';
import text12 from '../learnertexts_B2/text12.json';
import text13 from '../learnertexts_B2/text13.json';
import text14 from '../learnertexts_B2/text14.json';
import text15 from '../learnertexts_B2/text15.json';
import text16 from '../learnertexts_B2/text16.json';
import text17 from '../learnertexts_B2/text17.json';
import text18 from '../learnertexts_B2/text18.json';
import text19 from '../learnertexts_B2/text19.json';
import text20 from '../learnertexts_B2/text20.json';
import text21 from '../learnertexts_B2/text21.json';
import text22 from '../learnertexts_B2/text22.json';
import text23 from '../learnertexts_B2/text23.json';
import text24 from '../learnertexts_B2/text24.json';
import text25 from '../learnertexts_B2/text25.json';
import text26 from '../learnertexts_B2/text26.json';

@Component({
  selector: 'app-texts-b2',
  templateUrl: './texts-b2.component.html',
  styleUrls: ['./texts-b2.component.css']
})
export class TextsB2Component implements OnInit {

  constructor(private router: Router, private unknownWordsService: UnknownWordsService, private textIdService: TextIdService) { }

  public titlesB2 = [
    "Barriere architettoniche",
    "Telefonata di Capodanno",
    "Cioccolata",
    "Inquinamento",
    "L'importanza di leggere",
    "Una traduzione speciale",
    "L'importanza di studiare una lingua straniera",
    "Lettera formale",
    "Oroscopo",
    "L'esame di maturità",
    "La vita di Carlo",
    "Cani abbandonati",
    "Università e scelte importanti",
    "Un ragazzo delicato",
    "Una festa noiosa",
    "Ritrovamento artistico",
    "Leggende metropolitane",
    "Beethoven",
    "Viaggiare a basso costo",
    "Vita da pensionato",
    "Amore per i libri",
    "Studiare all'estero",
    "La crisi economica",
    "Dipendenza da computer",
    "La disavventura di Mara",
    "Il festival della matematica"
  ]
  public currentTitle:string;
  //the buttons with the titles of the learner text are visible before selecting one text,
  //after click on one of the title buttons they all hide and the learner text + submit button are displayed
  private isButtonVisible = true; //necessary in html to hide title buttons and display text
  public textId:number;
  public wordsJsonText:{is_title:string, id:number, form:string, pos:string, 
                        lemma:string, has_context:string, toggled: boolean}[];
  //array to collect the words the user has clicked on in the text (= unknown):
  public unknownWords: Array<IUnknownWord> = [];

  ngOnInit() {
  }


  getLearnerText(aTitle){
    this.currentTitle = aTitle;
    this.textId = this.titlesB2.indexOf(this.currentTitle) + 1;
    //console.log(this.textId);
    this.displaySelectedB1Text(this.textId);
  }

  onClickMe(lemma, pos, id){
    var singleUnknownWord = { lemma: lemma, pos: pos, id: id};  //create object
    var containsObject = false;
    for (var i = 0; i < this.unknownWords.length; i++) {
        if (this.unknownWords[i].lemma == lemma && 
            this.unknownWords[i].pos == pos &&
            this.unknownWords[i].id == id) {
          containsObject = true;
          break;
        }
    } 
    if(containsObject){
      // if the word is present in the list of unknonwn words...
      this.unknownWords.splice(i, 1); //...delete it from array
    } else {
      //if the word object is not present in the list of unkown words...
      this.unknownWords.push(singleUnknownWord); //...put it into array
    }
  }


  onClickSubmit(){
    //sort out duplicates (same lemma + same pos, id doesnt matter!)
    let unknownWordsSorted: Array<IUnknownWord> = [];

    for (var i = 0; i < this.unknownWords.length; i++){
      var currentWord = this.unknownWords[i];
      var containsCurrentWord = false;

      for (var j = 0; j < unknownWordsSorted.length; j++){
        if (unknownWordsSorted[j].lemma == currentWord.lemma && 
        unknownWordsSorted[j].pos == currentWord.pos) {
          containsCurrentWord = true;
          break;
        } else {
          containsCurrentWord = false;
        }
      }
      //only if currentWord is not already in unknownWordsSorted...
      if(!containsCurrentWord){
        unknownWordsSorted.push(currentWord); //...put it into array
      }
    }
    //finally put words to service so next component 'context' can get the unkonwnWordsSorted from there
    this.unknownWordsService.unknownWords = unknownWordsSorted;
    this.textIdService.currentTextID = this.textId;
    this.textIdService.currentLevel = "B2";
    this.router.navigate(['context']);
  }

  
  toggleColor(item) {
    item.toggled = !item.toggled;
  }

  displaySelectedB1Text(anId){
    switch(anId) { 
      case 1: { 
        this.wordsJsonText = text1;
        //Apparently this is not even needed as boolean default 'undefined' is 
        //changed when toggleColor is invoked for the first time:
        //this.wordsJsonText.map((word) => {
        //  word.toggled = false;
        //  return word;
        //})
        break; 
      } 
      case 2: {
        this.wordsJsonText = text2;
        break; 
      } 
      case 3: { 
        this.wordsJsonText = text3;
        break; 
      } 
      case 4: {
        this.wordsJsonText = text4;
        break; 
      }
      case 5: { 
        this.wordsJsonText = text5;
        break; 
      } 
      case 6: {
        this.wordsJsonText = text6;
        break; 
      }
      case 7: { 
        this.wordsJsonText = text7;
        break; 
      } 
      case 8: {
        this.wordsJsonText = text8;
        break; 
      }
      case 9: { 
        this.wordsJsonText = text9;
        break; 
      } 
      case 10: {
        this.wordsJsonText = text10;
        break; 
      }
      case 11: { 
        this.wordsJsonText = text11;
        break; 
      } 
      case 12: {
        this.wordsJsonText = text12;
        break; 
      } 
      case 13: { 
        this.wordsJsonText = text13;
        break; 
      } 
      case 14: {
        this.wordsJsonText = text14;
        break; 
      }
      case 15: { 
        this.wordsJsonText = text15;
        break; 
      } 
      case 16: {
        this.wordsJsonText = text16;
        break; 
      }
      case 17: { 
        this.wordsJsonText = text17;
        break; 
      } 
      case 18: {
        this.wordsJsonText = text18;
        break; 
      }
      case 19: { 
        this.wordsJsonText = text19;
        break; 
      } 
      case 20: {
        this.wordsJsonText = text20;
        break; 
      }
      case 21: { 
        this.wordsJsonText = text21;
        break; 
      } 
      case 22: {
        this.wordsJsonText = text22;
        break; 
      } 
      case 23: { 
        this.wordsJsonText = text23;
        break; 
      } 
      case 24: {
        this.wordsJsonText = text24;
        break; 
      }
      case 25: { 
        this.wordsJsonText = text25;
        break; 
      }
      case 26: { 
        this.wordsJsonText = text26;
        break; 
      }
      default: { 
        //statements; 
        break; 
      } 
    } 
  
  }

}
