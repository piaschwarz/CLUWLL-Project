import { Injectable } from '@angular/core';
import { IUnknownWord } from './iunknownWord';

@Injectable({
  providedIn: 'root'
})

export class UnknownWordsService {
  
  unknownWords: Array<IUnknownWord>;

  constructor() { }
}


