import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flashcards-frequent',
  templateUrl: './flashcards-frequent.component.html',
  styleUrls: ['./flashcards-frequent.component.css']
})
export class FlashcardsFrequentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
