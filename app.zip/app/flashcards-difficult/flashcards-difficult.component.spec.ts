import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlashcardsDifficultComponent } from './flashcards-difficult.component';

describe('FlashcardsDifficultComponent', () => {
  let component: FlashcardsDifficultComponent;
  let fixture: ComponentFixture<FlashcardsDifficultComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlashcardsDifficultComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlashcardsDifficultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
