import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flashcards-encountered',
  templateUrl: './flashcards-encountered.component.html',
  styleUrls: ['./flashcards-encountered.component.css']
})
export class FlashcardsEncounteredComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
