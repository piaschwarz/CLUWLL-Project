import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { UnknownWordsService } from '../unknown-words.service';
import { StillUnknownWordsService } from '../stillunknown-words.service';
import { IUnknownWord } from '../iunknownWord'
import { TextIdService } from '../text-id.service'

import b1text1 from '../learnertexts_B1/text1.json';
import b1text2 from '../learnertexts_B1/text2.json';
import b1text3 from '../learnertexts_B1/text3.json';
import b1text4 from '../learnertexts_B1/text4.json';
import b1text5 from '../learnertexts_B1/text5.json';
import b1text6 from '../learnertexts_B1/text6.json';
import b1text7 from '../learnertexts_B1/text7.json';
import b1text8 from '../learnertexts_B1/text8.json';
import b1text9 from '../learnertexts_B1/text9.json';
import b1text10 from '../learnertexts_B1/text10.json';
import b1text11 from '../learnertexts_B1/text11.json';
import b1text12 from '../learnertexts_B1/text12.json';
import b1text13 from '../learnertexts_B1/text13.json';
import b1text14 from '../learnertexts_B1/text14.json';
import b1text15 from '../learnertexts_B1/text15.json';
import b1text16 from '../learnertexts_B1/text16.json';
import b1text17 from '../learnertexts_B1/text17.json';
import b1text18 from '../learnertexts_B1/text18.json';
import b1text19 from '../learnertexts_B1/text19.json';
import b1text20 from '../learnertexts_B1/text20.json';
import b1text21 from '../learnertexts_B1/text21.json';
import b1text22 from '../learnertexts_B1/text22.json';
import b1text23 from '../learnertexts_B1/text23.json';
import b1text24 from '../learnertexts_B1/text24.json';
import b1text25 from '../learnertexts_B1/text25.json';

import b2text1 from '../learnertexts_B2/text1.json';
import b2text2 from '../learnertexts_B2/text2.json';
import b2text3 from '../learnertexts_B2/text3.json';
import b2text4 from '../learnertexts_B2/text4.json';
import b2text5 from '../learnertexts_B2/text5.json';
import b2text6 from '../learnertexts_B2/text6.json';
import b2text7 from '../learnertexts_B2/text7.json';
import b2text8 from '../learnertexts_B2/text8.json';
import b2text9 from '../learnertexts_B2/text9.json';
import b2text10 from '../learnertexts_B2/text10.json';
import b2text11 from '../learnertexts_B2/text11.json';
import b2text12 from '../learnertexts_B2/text12.json';
import b2text13 from '../learnertexts_B2/text13.json';
import b2text14 from '../learnertexts_B2/text14.json';
import b2text15 from '../learnertexts_B2/text15.json';
import b2text16 from '../learnertexts_B2/text16.json';
import b2text17 from '../learnertexts_B2/text17.json';
import b2text18 from '../learnertexts_B2/text18.json';
import b2text19 from '../learnertexts_B2/text19.json';
import b2text20 from '../learnertexts_B2/text20.json';
import b2text21 from '../learnertexts_B2/text21.json';
import b2text22 from '../learnertexts_B2/text22.json';
import b2text23 from '../learnertexts_B2/text23.json';
import b2text24 from '../learnertexts_B2/text24.json';
import b2text25 from '../learnertexts_B2/text25.json';
import b2text26 from '../learnertexts_B2/text26.json';

@Component({
  selector: 'app-wrapup',
  templateUrl: './wrapup.component.html',
  styleUrls: ['./wrapup.component.css']
})
export class WrapupComponent implements OnInit {

  constructor(private router: Router, private unknownWordsService: UnknownWordsService, 
    private stillUnknownWordsService: StillUnknownWordsService, private textIdService: TextIdService) { };

  public unknownWords: Array<IUnknownWord> = []; //array
  public stillUnknownWords: Array<IUnknownWord> = []; //array
  public textId: number;
  public level: string;
  public wordsJsonText:{is_title:string, id:number, form:string, pos:string, 
    lemma:string, has_context:string, toggled: boolean}[];

  ngOnInit() {
    this.unknownWords = this.unknownWordsService.unknownWords
    this.textId = this.textIdService.currentTextID;
    this.level = this.textIdService.currentLevel;
    this.collectJsonText(this.textId, this.level)
  }


  isPartOfUnknownWords(aLemma, aPos, anId){
    var singleUnknownWord = { lemma: aLemma, pos: aPos, id: anId};  //create object
    var containsObject = false;

    for (var i = 0; i < this.unknownWords.length; i++) {
        if (this.unknownWords[i].lemma == aLemma && 
            this.unknownWords[i].pos == aPos &&
            this.unknownWords[i].id == anId) {
          containsObject = true;
          break;
        }
    } 
    if(containsObject){
      // if the word is present in the list of unknonwn words...
      return true;
    } else {
      //if the word object is not present in the list of unkown words...
      return false;
    }
  }


  onClickMe(lemma, pos, id){
    var singleUnknownWord = { lemma: lemma, pos: pos, id: id};  //create object
    var containsObject = false;

    for (var i = 0; i < this.stillUnknownWords.length; i++) {
        if (this.stillUnknownWords[i].lemma == lemma && 
            this.stillUnknownWords[i].pos == pos &&
            this.stillUnknownWords[i].id == id) {
          containsObject = true;
          break;
        }
    } 
    if(containsObject){
      // if the word is present in the list of unknonwn words...
      this.stillUnknownWords.splice(i, 1); //...delete it from array
    } else {
      //if the word object is not present in the list of unkown words...
      this.stillUnknownWords.push(singleUnknownWord); //...put it into array
    }
  }


  onClickSubmit(){
    //sort out duplicates (same lemma + same pos, id doesnt matter!)
    let stillUnknownWordsSorted: Array<IUnknownWord> = [];

    for (var i = 0; i < this.stillUnknownWords.length; i++){
      var currentWord = this.stillUnknownWords[i];
      var containsCurrentWord = false;

      for (var j = 0; j < stillUnknownWordsSorted.length; j++){
        if (stillUnknownWordsSorted[j].lemma == currentWord.lemma && 
        stillUnknownWordsSorted[j].pos == currentWord.pos) {
          containsCurrentWord = true;
          break;
        } else {
          containsCurrentWord = false;
        }
      }
      //only if currentWord is not already in unknownWordsSorted...
      if(!containsCurrentWord){
        stillUnknownWordsSorted.push(currentWord); //...put it into array
      }
    }
    //finally put words to service so the last component can get the stillUnkonwnWordsSorted from there
    this.stillUnknownWordsService.stillUnknownWords = stillUnknownWordsSorted;

    //this.router.navigate(['context']); //TO DO: navigate to last component
  }


  toggleColor(item) {
    item.toggled = !item.toggled;
  }


  collectJsonText(anId, aLvl){
    if(aLvl == "B1"){
      switch(anId) { 
        case 1: { 
          this.wordsJsonText = b1text1;
          //Apparently this is not even needed as boolean default 'undefined' is 
          //changed when toggleColor is invoked for the first time:
          //this.wordsJsonText.map((word) => {
          //  word.toggled = false;
          //  return word;
          //})
          break; 
        } 
        case 2: {
          this.wordsJsonText = b1text2;
          break; 
        } 
        case 3: { 
          this.wordsJsonText = b1text3;
          break; 
        } 
        case 4: {
          this.wordsJsonText = b1text4;
          break; 
        }
        case 5: { 
          this.wordsJsonText = b1text5;
          break; 
        } 
        case 6: {
          this.wordsJsonText = b1text6;
          break; 
        }
        case 7: { 
          this.wordsJsonText = b1text7;
          break; 
        } 
        case 8: {
          this.wordsJsonText = b1text8;
          break; 
        }
        case 9: { 
          this.wordsJsonText = b1text9;
          break; 
        } 
        case 10: {
          this.wordsJsonText = b1text10;
          break; 
        }
        case 11: { 
          this.wordsJsonText = b1text11;
          break; 
        } 
        case 12: {
          this.wordsJsonText = b1text12;
          break; 
        } 
        case 13: { 
          this.wordsJsonText = b1text13;
          break; 
        } 
        case 14: {
          this.wordsJsonText = b1text14;
          break; 
        }
        case 15: { 
          this.wordsJsonText = b1text15;
          break; 
        } 
        case 16: {
          this.wordsJsonText = b1text16;
          break; 
        }
        case 17: { 
          this.wordsJsonText = b1text17;
          break; 
        } 
        case 18: {
          this.wordsJsonText = b1text18;
          break; 
        }
        case 19: { 
          this.wordsJsonText = b1text19;
          break; 
        } 
        case 20: {
          this.wordsJsonText = b1text20;
          break; 
        }
        case 21: { 
          this.wordsJsonText = b1text21;
          break; 
        } 
        case 22: {
          this.wordsJsonText = b1text22;
          break; 
        } 
        case 23: { 
          this.wordsJsonText = b1text23;
          break; 
        } 
        case 24: {
          this.wordsJsonText = b1text24;
          break; 
        }
        case 25: { 
          this.wordsJsonText = b1text25;
          break; 
        } 
        default: { 
          //statements; 
          break; 
        } 
      } 

      if(aLvl == "B2"){
        switch(anId) { 
          case 1: { 
            this.wordsJsonText = b2text1;
            //Apparently this is not even needed as boolean default 'undefined' is 
            //changed when toggleColor is invoked for the first time:
            //this.wordsJsonText.map((word) => {
            //  word.toggled = false;
            //  return word;
            //})
            break; 
          } 
          case 2: {
            this.wordsJsonText = b2text2;
            break; 
          } 
          case 3: { 
            this.wordsJsonText = b2text3;
            break; 
          } 
          case 4: {
            this.wordsJsonText = b2text4;
            break; 
          }
          case 5: { 
            this.wordsJsonText = b2text5;
            break; 
          } 
          case 6: {
            this.wordsJsonText = b2text6;
            break; 
          }
          case 7: { 
            this.wordsJsonText = b2text7;
            break; 
          } 
          case 8: {
            this.wordsJsonText = b2text8;
            break; 
          }
          case 9: { 
            this.wordsJsonText = b2text9;
            break; 
          } 
          case 10: {
            this.wordsJsonText = b2text10;
            break; 
          }
          case 11: { 
            this.wordsJsonText = b2text11;
            break; 
          } 
          case 12: {
            this.wordsJsonText = b2text12;
            break; 
          } 
          case 13: { 
            this.wordsJsonText = b2text13;
            break; 
          } 
          case 14: {
            this.wordsJsonText = b2text14;
            break; 
          }
          case 15: { 
            this.wordsJsonText = b2text15;
            break; 
          } 
          case 16: {
            this.wordsJsonText = b2text16;
            break; 
          }
          case 17: { 
            this.wordsJsonText = b2text17;
            break; 
          } 
          case 18: {
            this.wordsJsonText = b2text18;
            break; 
          }
          case 19: { 
            this.wordsJsonText = b2text19;
            break; 
          } 
          case 20: {
            this.wordsJsonText = b2text20;
            break; 
          }
          case 21: { 
            this.wordsJsonText = b2text21;
            break; 
          } 
          case 22: {
            this.wordsJsonText = b2text22;
            break; 
          } 
          case 23: { 
            this.wordsJsonText = b2text23;
            break; 
          } 
          case 24: {
            this.wordsJsonText = b2text24;
            break; 
          }
          case 25: { 
            this.wordsJsonText = b2text25;
            break; 
          } 
          case 26: { 
            this.wordsJsonText = b2text26;
            break; 
          } 
          default: { 
            //statements; 
            break; 
          } 
        } 
      }

    }
  }





}
