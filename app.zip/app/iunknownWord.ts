export interface IUnknownWord {
    lemma: string,
    pos: string,
    id: string
}
