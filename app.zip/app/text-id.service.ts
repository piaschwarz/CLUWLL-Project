import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class TextIdService {
  
  currentTextID: number;
  currentLevel: string;

  constructor() { }
}
