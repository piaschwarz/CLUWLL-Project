import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlashcardsA1A2Component } from './flashcards-a1-a2.component';

describe('FlashcardsA1A2Component', () => {
  let component: FlashcardsA1A2Component;
  let fixture: ComponentFixture<FlashcardsA1A2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlashcardsA1A2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlashcardsA1A2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
