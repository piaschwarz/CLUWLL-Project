import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { IUnknownWord } from '../iunknownWord'
import { UnknownWordsService } from '../unknown-words.service';
import { ContextService } from '../context.service';
import { HttpClientModule} from '@angular/common/http';
import { IContextSentence } from '../icontextSentence';

@Component({
  selector: 'app-context',
  templateUrl: './context.component.html',
  styleUrls: ['./context.component.css']
})
export class ContextComponent implements OnInit {

  constructor(private router: Router, private unknownWordsService: UnknownWordsService, private contextService: ContextService) { };

  public unknownWords: Array<IUnknownWord> = []; //array
  public returnedContextSentences: Array<IContextSentence> = [];
  public currentCS: IContextSentence;
  public indexI: number;
  public indexJ: number;

  ngOnInit() {

    this.unknownWords = this.unknownWordsService.unknownWords

    for (let i = 0; i < this.unknownWords.length; i++) {
      var lemma = this.unknownWords[i].lemma;
      var pos = this.unknownWords[i].pos;
      var currentUrl = "http://localhost:8080/Chinese/RandomStatic?lemma="+lemma+"&pos="+pos;
      this.retrieveContextSentences(currentUrl);
    }
    
  }

  /*
  calls context.service.ts which then retrieves the data via URL 
  and Java Servlet from the SQL database
  */
  retrieveContextSentences(aUrl){
    this.contextService.getContextSentences(aUrl).subscribe((res : IContextSentence) => 
    { 
      this.returnedContextSentences.push(res);
      // call all functions that deal with returnedContextSenentes array INSIDE the subscribe-call
      // as it recieves its items asynchronously and will be updated over time
    });
    
  }

  goToPractice(){
    this.router.navigate(['practice']);
  }


}
