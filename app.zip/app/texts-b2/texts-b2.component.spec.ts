import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TextsB2Component } from './texts-b2.component';

describe('TextsB2Component', () => {
  let component: TextsB2Component;
  let fixture: ComponentFixture<TextsB2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TextsB2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TextsB2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
