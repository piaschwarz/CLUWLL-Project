import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlashcardsEncounteredComponent } from './flashcards-encountered.component';

describe('FlashcardsEncounteredComponent', () => {
  let component: FlashcardsEncounteredComponent;
  let fixture: ComponentFixture<FlashcardsEncounteredComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlashcardsEncounteredComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlashcardsEncounteredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
