import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { IContextSentence } from './icontextSentence';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContextService {

  //private _url: string = "/assets/vocab.json"
  //private _url: string = "http://localhost:8080/Chinese/RandomStatic?lemma=zodiacale&pos=ADJ"


  constructor(private http: HttpClient) { }
  

  getContextSentences(aUrl): Observable<IContextSentence> {
    return this.http.get<IContextSentence>(aUrl);
  }
}
