import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { IContextSentence } from './icontextSentence';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  //private _url: string = "http://localhost:8080/Chinese/LoginServlet?username=marta"

  constructor(private http: HttpClient) { }

  sendUsername(aUrl): Observable<String> {
    return this.http.get<String>(aUrl);
  }
}