import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TextsB1Component } from './texts-b1.component';

describe('TextsB1Component', () => {
  let component: TextsB1Component;
  let fixture: ComponentFixture<TextsB1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TextsB1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TextsB1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
