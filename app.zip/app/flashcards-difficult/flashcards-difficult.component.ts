import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flashcards-difficult',
  templateUrl: './flashcards-difficult.component.html',
  styleUrls: ['./flashcards-difficult.component.css']
})
export class FlashcardsDifficultComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
