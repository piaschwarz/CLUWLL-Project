import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlashcardsFrequentComponent } from './flashcards-frequent.component';

describe('FlashcardsFrequentComponent', () => {
  let component: FlashcardsFrequentComponent;
  let fixture: ComponentFixture<FlashcardsFrequentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlashcardsFrequentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlashcardsFrequentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
