import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-mainmenu',
  templateUrl: './mainmenu.component.html',
  styleUrls: ['./mainmenu.component.css']
})
export class MainmenuComponent implements OnInit {

  public user;

  constructor(private router: Router, private loginService: LoginService) { }
  
  ngOnInit() {;
    this.user = sessionStorage.getItem('username');
    console.log(this.user); //to be deleted

    //create http call and send username so a sql table for the learner can be created
    var currentUrl = "http://localhost:8080/Chinese/LoginServlet?username=" + this.user;
    this.loginService.sendUsername(currentUrl).subscribe((res : String) => 
    { 
      console.log(res);
    });


  }

  goToB1(){
    this.router.navigate(['textsB1'])
  }

  goToB2(){
    this.router.navigate(['textsB2'])
  }

  goToFCardsA1A2(){
    this.router.navigate(['flashcardsa1a2'])
  }

  goToFCardsDifficult()  {
    this.router.navigate(['fcardsDifficult'])
  }

  goToFCardsFrequent(){
    this.router.navigate(['fcardsFrequent'])
  }

  goToFCardsEncountered(){
    this.router.navigate(['fcardsEncountered'])
  }

}
