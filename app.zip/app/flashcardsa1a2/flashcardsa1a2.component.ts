import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flashcards-a1-a2',
  templateUrl: './flashcardsa1a2.component.html',
  styleUrls: ['./flashcardsa1a2.component.css']
})
export class Flashcardsa1a2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
