import { TestBed } from '@angular/core/testing';

import { UnknownWordsService } from './unknown-words.service';

describe('UnknownWordsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UnknownWordsService = TestBed.get(UnknownWordsService);
    expect(service).toBeTruthy();
  });
});
