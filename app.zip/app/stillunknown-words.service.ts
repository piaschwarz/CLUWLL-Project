import { Injectable } from '@angular/core';
import { IUnknownWord } from './iunknownWord';

@Injectable({
  providedIn: 'root'
})

export class StillUnknownWordsService {
  
  stillUnknownWords: Array<IUnknownWord>;

  constructor() { }
}
