export interface IContextSentence {
    sent1ita: string;
    sent2ita: string;
    sent3ita: string;
    sent1deu: string;
    sent2deu: string;
    sent3deu: string;
    stringmatch1ita: string;
    stringmatch2ita: string;
    stringmatch3ita: string;
    stringmatch1deu: string;
    stringmatch2deu: string;
    stringmatch3deu: string;
    sent1itablanked: string;
    sent2itablanked: string;
    sent3itablanked: string;
    sent1deublanked: string;
    sent2deublanked: string;
    sent3deublanked: string;
    lemmaCS: string;
    posCS: string;
}
