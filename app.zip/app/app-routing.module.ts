import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from '../app/login/login.component';
import {MainmenuComponent} from '../app/mainmenu/mainmenu.component';
import {TextsB1Component} from '../app/texts-b1/texts-b1.component';
import {TextsB2Component} from '../app/texts-b2/texts-b2.component';
import {Flashcardsa1a2Component} from '../app/flashcardsa1a2/flashcardsa1a2.component';
import {FlashcardsDifficultComponent} from '../app/flashcards-difficult/flashcards-difficult.component';
import {FlashcardsEncounteredComponent} from '../app/flashcards-encountered/flashcards-encountered.component';
import {FlashcardsFrequentComponent} from '../app/flashcards-frequent/flashcards-frequent.component';
import {ContextComponent} from '../app/context/context.component';
import {PracticeComponent} from '../app/practice/practice.component';
import {WrapupComponent} from '../app/wrapup/wrapup.component';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'mainmenu', component: MainmenuComponent },
  { path: 'textsB1', component: TextsB1Component },
  { path: 'textsB2', component: TextsB2Component },
  { path: 'flashcardsa1a2', component: Flashcardsa1a2Component },
  { path: 'fcardsDifficult', component: FlashcardsDifficultComponent },
  { path: 'fcardsEncountered', component: FlashcardsEncounteredComponent },
  { path: 'fcardsFrequent', component: FlashcardsFrequentComponent },
  { path: 'context', component: ContextComponent},
  { path: 'practice', component: PracticeComponent},
  { path: 'wrapup', component: WrapupComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponents = [
  LoginComponent, 
  MainmenuComponent, 
  TextsB1Component, 
  TextsB2Component,
  Flashcardsa1a2Component,
  FlashcardsDifficultComponent,
  FlashcardsEncounteredComponent,
  FlashcardsFrequentComponent,
  ContextComponent,
  PracticeComponent,
  WrapupComponent
] 
//...and in app.module.ts, import routingComponents + add it to the @NgModule declarator
//usually this is added both automatically but better double check
