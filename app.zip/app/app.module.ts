import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { MainmenuComponent } from './mainmenu/mainmenu.component';
import { TextsB1Component } from './texts-b1/texts-b1.component';
import { TextsB2Component } from './texts-b2/texts-b2.component';
import { Flashcardsa1a2Component } from './flashcardsa1a2/flashcardsa1a2.component';
import { FlashcardsEncounteredComponent } from './flashcards-encountered/flashcards-encountered.component';
import { FlashcardsDifficultComponent } from './flashcards-difficult/flashcards-difficult.component';
import { FlashcardsFrequentComponent } from './flashcards-frequent/flashcards-frequent.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ContextComponent } from './context/context.component';
import { PracticeComponent } from './practice/practice.component';
import { WrapupComponent } from './wrapup/wrapup.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MainmenuComponent,
    TextsB1Component,
    TextsB2Component,
    Flashcardsa1a2Component,
    FlashcardsEncounteredComponent,
    FlashcardsDifficultComponent,
    FlashcardsFrequentComponent,
    ContextComponent,
    PracticeComponent,
    WrapupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
