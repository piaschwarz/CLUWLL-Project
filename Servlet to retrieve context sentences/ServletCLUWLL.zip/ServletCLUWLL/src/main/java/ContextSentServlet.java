import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;


import javax.servlet.*;
import javax.servlet.http.*;



public class ContextSentServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static String USER = "marta";
	private static String PASS = "colewe";
	private Connection conn;
	
	private void setAccessControlHeaders(HttpServletResponse resp) {
	    resp.setHeader("Access-Control-Allow-Origin", "*");
	    resp.setHeader("Access-Control-Allow-Methods", "GET");
	}
			
	public void doGet(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
		setAccessControlHeaders(response);
		response.setCharacterEncoding("UTF-8");		
		response.setContentType("text/plain");
		PrintWriter out = new PrintWriter(new OutputStreamWriter(response.getOutputStream(), "UTF8"));
				
		String lemma = request.getParameter("lemma");
        
        
        
      	//out.println("<html><body>");
		//out.println("<h1>Retrieval of context sentences</h1>");
			
		try {
			// Register JDBC driver
			Class.forName("com.mysql.cj.jdbc.Driver");
	    	String DB_URL = "jdbc:mysql://localhost/cluwll?serverTimezone=UTC";
	    	
	    	Properties info = new Properties();
	    	info.put( "user", USER );
	    	info.put( "password", PASS );
	    	info.put( "characterEncoding", "utf8" );
	    	
	    	//out.println("<h2>works until here!</h2>");
	    	Connection conn = DriverManager.getConnection(DB_URL, info);
	    	
	    	//out.println("<h2>works</h2>");
	    	
	    	Statement stmt1 = conn.createStatement();
	    	
	    	
	    	//out.println("<h3>works til here yuhu</h3>");
	    	
			ResultSet rs = stmt1.executeQuery("SELECT* FROM static WHERE lemma='"+lemma+"';");
			
			
			//out.println("<h3>and here too</h3>");
			
	    	
	    	
	        
	       
	    	
	        JSONArray ja = new JSONArray();  
	        
	    	while (rs.next()) {
	    		
		   		String sent1ita = rs.getString("sent1ita");
		   		String sent2ita = rs.getString("sent2ita");
		   		String sent3ita = rs.getString("sent3ita");
		   		
		   		//out.print("[" + sent1ita + "," + sent2ita + "," + sent3ita + "]");
		   		
		   		
		   		
		   		
		   		JSONObject jo = new JSONObject();
		   		jo.put("sent1ita", sent1ita);
		   		jo.put("sent2ita", sent2ita);
		   		jo.put("sent3ita", sent3ita);
		   		
		   		ja.put(jo);
		   		
		   		
		   		
		   		
		   		
		   		
		   		
		   		
		        
	    	}
	    	
	   		//print out json object
	        out.print(ja);
	    	
	    	conn.close();
			
		} catch (SQLException e){
			e.printStackTrace();
		} catch (Exception ex) {
		    Logger lgr = Logger.getLogger(Random.class.getName());
		    lgr.log(Level.SEVERE, ex.getMessage(), ex);
		}
		
		out.close();
		
	}
	
	
	
	
	

}
